# Generador de Etiquetas Seriales con Código de Barras

Proyecto web para generar etiquetas con seriales y códigos de barras, guardando los registros en Google Sheets mediante Google Apps Script.

---

## Estructura del proyecto

- `index.html`: Página web con formulario.
- `styles.css`: Estilos modernos y responsivos.
- `app.js`: Lógica frontend, conexión con Apps Script.
- `Code.gs`: Backend Google Apps Script para guardar datos en Google Sheets.

---

## Configuración

1. **Google Sheets:**

   - Crea un Google Sheet.
   - Agrega una hoja llamada `Registro_Serial`.
   - Las columnas deben ser: `ID`, `Material`, `Descripción`, `UM`, `Serial`, `Fecha`.

2. **Google Apps Script:**

   - Entra a [Google Apps Script](https://script.google.com/).
   - Crea un proyecto nuevo.
   - Copia y pega el código `Code.gs`.
   - Cambia `SPREADSHEET_ID` por el ID de tu hoja (el valor entre `/d/` y `/edit` en la URL).
   - Guarda.

3. **Despliegue Web App:**

   - Ve a `Deploy > New Deployment > Web app`.
   - Pon un nombre.
   - En "Who has access" elige "Anyone" o "Anyone with link".
   - Copia la URL del Web App desplegado.

4. **Frontend:**

   - En `app.js`, reemplaza la variable `SCRIPT_URL` con la URL del Web App desplegado.
   - Sube los archivos `index.html`, `styles.css` y `app.js` a un repositorio en GitHub.
   - En la configuración del repositorio, activa GitHub Pages para la rama y carpeta donde están los archivos (por ejemplo, rama main y root `/`).

5. **Uso:**

   - Abre la URL de GitHub Pages.
   - Llena el formulario y guarda.
   - Verás el código de barras generado.
   - Los datos se guardarán en Google Sheets.

---

## Recomendaciones

- Asegúrate que la hoja `Registro_Serial` existe y está correctamente nombrada.
- El usuario que despliega el Apps Script debe tener permisos para editar la hoja.
- Para producción, considera añadir seguridad o autenticación al backend Apps Script.
- Puedes extender la aplicación para buscar o borrar registros.

---

## Contacto

Para soporte o mejoras, contáctame.

---
